package quickchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LoginTest {

    private Login login;

    @BeforeEach
    void setUp() {
        login = new Login("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    }

    @Test
    void usernameCorrectlyFormatted_returnsWelcomeOnLogin() {
        assertTrue(login.checkUserName());
        login.registerUser();
        assertEquals("Welcome Kyle, Smith it is great to see you again.", login.returnLoginStatus());
    }

    @Test
    void usernameIncorrectlyFormatted() {
        login.setUsername("kyle!!!!!!!");
        assertFalse(login.checkUserName());
        assertEquals(
                "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
                login.getUsernameMessage()
        );
    }

    @Test
    void passwordMeetsComplexity() {
        login.setPassword("Ch&&sec@ke99!");
        assertTrue(login.checkPasswordComplexity());
        assertEquals("Password successfully captured.", login.getPasswordMessage());
    }

    @Test
    void passwordDoesNotMeetComplexity() {
        login.setPassword("password");
        assertFalse(login.checkPasswordComplexity());
        assertEquals(
                "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                login.getPasswordMessage()
        );
    }

    @Test
    void cellPhoneCorrectlyFormatted() {
        login.setCellPhone("+27838968976");
        assertTrue(login.checkCellPhoneNumber());
        assertEquals("Cell number successfully captured.", login.getCellPhoneMessage());
    }

    @Test
    void cellPhoneIncorrectlyFormatted() {
        login.setCellPhone("08966553");
        assertFalse(login.checkCellPhoneNumber());
        assertEquals(
                "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
                login.getCellPhoneMessage()
        );
    }

    @Test
    void loginSuccessful() {
        login.registerUser();
        assertTrue(login.loginUser());
    }

    @Test
    void loginFailed() {
        login.registerUser();
        login.setPassword("WrongPass1!");
        assertFalse(login.loginUser());
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus());
    }

    @Test
    void usernameCorrectlyFormattedBoolean() {
        login.setUsername("kyl_1");
        assertTrue(login.checkUserName());
    }

    @Test
    void usernameIncorrectlyFormattedBoolean() {
        login.setUsername("kyle!!!!!!!");
        assertFalse(login.checkUserName());
    }
}
