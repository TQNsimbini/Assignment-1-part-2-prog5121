package quickchat;

import java.util.Scanner;

/**
 * QuickChat console application.
 * Part 1: register and log in. Part 2: send messages after a successful login.
 */
public class QuickChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== QuickChat Registration (Part 1) ===");
        System.out.print("Enter first name: ");
        login.setFirstName(scanner.nextLine().trim());
        System.out.print("Enter last name: ");
        login.setLastName(scanner.nextLine().trim());
        System.out.print("Enter username: ");
        login.setUsername(scanner.nextLine().trim());
        System.out.println(login.getUsernameMessage());
        System.out.print("Enter password: ");
        login.setPassword(scanner.nextLine());
        System.out.println(login.getPasswordMessage());
        System.out.print("Enter South African cell phone number (with international code): ");
        login.setCellPhone(scanner.nextLine().trim());
        System.out.println(login.getCellPhoneMessage());
        System.out.println(login.registerUser());

        System.out.println("\n=== Login ===");
        System.out.print("Username: ");
        login.setUsername(scanner.nextLine().trim());
        System.out.print("Password: ");
        login.setPassword(scanner.nextLine());
        System.out.println(login.returnLoginStatus());

        if (!login.loginUser()) {
            System.out.println("You must log in successfully before sending messages.");
            return;
        }

        System.out.println("Welcome to QuickChat.");
        boolean running = true;
        while (running) {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Option: ");
            String option = scanner.nextLine().trim();

            switch (option) {
                case "1":
                    sendMessages(scanner);
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    System.out.println("Goodbye.");
                    break;
                default:
                    System.out.println("Invalid option. Please enter 1, 2, or 3.");
                    break;
            }
        }
    }

    private static void sendMessages(Scanner scanner) {
        System.out.print("How many messages do you wish to enter? ");
        int count;
        try {
            count = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
            return;
        }
        if (count < 1) {
            System.out.println("You must enter at least one message.");
            return;
        }

        Message printer = new Message();
        for (int i = 0; i < count; i++) {
            System.out.println("\n--- Message " + (i + 1) + " of " + count + " ---");
            Message current = new Message();
            current.setMessageNumber(i);

            System.out.print("Recipient cell number: ");
            current.setRecipient(scanner.nextLine().trim());
            System.out.println(current.checkRecipientCell());
            if (!Login.isValidCellNumber(current.getRecipient())) {
                System.out.println("Message not captured because the recipient number is invalid.");
                continue;
            }

            System.out.print("Enter message (max 250 characters): ");
            current.setMessage(scanner.nextLine());
            String lengthMessage = current.checkMessageLength();
            System.out.println(lengthMessage);
            if (current.getMessage().length() > 250) {
                continue;
            }

            current.createMessageHash();
            System.out.println("Choose: 1) Send Message  2) Disregard Message  3) Store Message to send later");
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid option.");
                continue;
            }
            System.out.println(current.SentMessage(choice));

            if (choice == Message.SEND) {
                System.out.println(current.getDisplayDetails());
            }
        }

        System.out.println("\nTotal messages sent: " + printer.returnTotalMessagess());
        String sentDetails = printer.printMessages();
        if (!sentDetails.isBlank()) {
            System.out.println("\nSent message details:");
            System.out.println(sentDetails);
        }
    }
}
