package quickchat;

import java.util.regex.Pattern;

/**
 * Part 1 registration and login. Part 2 reuses the cell-number checker for
 * message recipients.
 */
public class Login {

    private String username;
    private String password;
    private String cellPhone;
    private String firstName;
    private String lastName;
    private String storedUsername;
    private String storedPassword;
    private boolean registered;

    /**
     * South African cell numbers: international code followed by a number of
     * at most ten digits.
     *
     * Regular-expression approach adapted from Oracle's Pattern documentation:
     * https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html
     */
    private static final Pattern CELL_PATTERN = Pattern.compile("^\\+\\d{1,3}\\d{1,10}$");

    public Login() {
    }

    public Login(String firstName, String lastName, String username, String password, String cellPhone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
    }

    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }
        boolean hasCapital = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        return hasCapital && hasDigit && hasSpecial;
    }

    public boolean checkCellPhoneNumber() {
        return isValidCellNumber(cellPhone);
    }

    /**
     * Shared with Part 2 recipient validation.
     */
    public static boolean isValidCellNumber(String number) {
        return number != null && CELL_PATTERN.matcher(number).matches();
    }

    public String getUsernameMessage() {
        if (checkUserName()) {
            return "Username successfully captured.";
        }
        return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
    }

    public String getPasswordMessage() {
        if (checkPasswordComplexity()) {
            return "Password successfully captured.";
        }
        return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
    }

    public String getCellPhoneMessage() {
        if (checkCellPhoneNumber()) {
            return "Cell number successfully captured.";
        }
        return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
    }

    public String registerUser() {
        if (!checkUserName()) {
            return getUsernameMessage();
        }
        if (!checkPasswordComplexity()) {
            return getPasswordMessage();
        }
        if (!checkCellPhoneNumber()) {
            return getCellPhoneMessage();
        }
        storedUsername = username;
        storedPassword = password;
        registered = true;
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    public boolean loginUser() {
        return registered
                && username != null
                && password != null
                && username.equals(storedUsername)
                && password.equals(storedPassword);
    }

    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
