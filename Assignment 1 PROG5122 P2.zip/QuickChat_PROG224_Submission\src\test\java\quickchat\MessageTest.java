package quickchat;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MessageTest {

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        Message.resetSentMessages();
        Message.setStoreFile(tempDir.resolve("storedMessages.json"));
    }

    @Test
    void messageLengthSuccess() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", message.checkMessageLength());
    }

    @Test
    void messageLengthFailure() {
        String tooLong = "A".repeat(260);
        Message message = new Message("+27718693002", tooLong);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", message.checkMessageLength());
    }

    @Test
    void recipientCorrectlyFormatted_reusesPartOneCellCheck() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue(Login.isValidCellNumber(message.getRecipient()));
        assertEquals("Cell phone number successfully captured.", message.checkRecipientCell());
    }

    @Test
    void recipientIncorrectlyFormatted() {
        Message message = new Message("08575975889", "Hi Keegan, did you receive the payment?");
        assertFalse(Login.isValidCellNumber(message.getRecipient()));
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                message.checkRecipientCell()
        );
    }

    @Test
    void messageHashIsCorrectForTestCase1() {
        Message message = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", message.createMessageHash());
    }

    @Test
    void messageHashesInLoop() {
        String[] texts = {
                "Hi Mike, can you join us for dinner tonight?",
                "Hi Keegan, did you receive the payment?"
        };
        String[] expected = {
                "00:0:HITONIGHT",
                "00:1:HIPAYMENT"
        };
        for (int i = 0; i < texts.length; i++) {
            Message message = new Message("0012345678", i, "+27718693002", texts[i]);
            assertEquals(expected[i], message.createMessageHash());
        }
    }

    @Test
    void messageIdIsCreated() {
        Message message = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
        assertTrue(message.getMessageID().matches("\\d{10}"));
    }

    @Test
    void sentMessageSend() {
        Message message = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message successfully sent.", message.SentMessage(Message.SEND));
        assertEquals(1, message.returnTotalMessagess());
    }

    @Test
    void sentMessageDisregard() {
        Message message = new Message("0012345678", 1, "08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals("Press 0 to delete the message.", message.SentMessage(Message.DISREGARD));
        assertEquals(0, message.returnTotalMessagess());
    }

    @Test
    void sentMessageStore() throws Exception {
        Message message = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message successfully stored.", message.SentMessage(Message.STORE));
        assertEquals(0, message.returnTotalMessagess());
        Path stored = tempDir.resolve("storedMessages.json");
        assertTrue(Files.exists(stored));
        String json = Files.readString(stored);
        assertTrue(json.contains("Hi Mike, can you join us for dinner tonight?"));
        assertTrue(json.contains("+27718693002"));
    }

    @Test
    void assignmentTestDataTwoMessages() {
        Message first = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", first.createMessageHash());
        assertEquals("Message successfully sent.", first.SentMessage(Message.SEND));

        Message second = new Message("0012345678", 1, "08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals("Press 0 to delete the message.", second.SentMessage(Message.DISREGARD));

        assertEquals(1, first.returnTotalMessagess());
        assertTrue(first.printMessages().contains("Hi Mike, can you join us for dinner tonight?"));
        assertFalse(first.printMessages().contains("Hi Keegan"));
    }
}
