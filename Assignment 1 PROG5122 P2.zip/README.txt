PROG224 QuickChat - Submission
Part 1: Registration and login
Part 2: Sending messages

------------------------------------------------
Student details 
------------------------------------------------
Full name: Tisetso Quan Nsimbini
Student number: ST10470505
Module: PROG5122

------------------------------------------------
What is included
------------------------------------------------
- src/main/java/quickchat/Login.java        Part 1 login/register
- src/main/java/quickchat/Message.java      Part 2 messages + JSON store
- src/main/java/quickchat/QuickChatApp.java Console application
- src/test/java/quickchat/LoginTest.java    Part 1 unit tests
- src/test/java/quickchat/MessageTest.java  Part 2 unit tests
- pom.xml                                  Maven / NetBeans project file

Part 2 only allows sending after a successful Part 1 login.
Recipient numbers reuse the Part 1 cell-phone regular expression.

------------------------------------------------
How to open and run in NetBeans
------------------------------------------------
1. File > Open Project
2. Select this folder (the one that contains pom.xml)
3. Right-click QuickChatApp.java > Run File
4. Right-click the project > Test to run JUnit tests

------------------------------------------------
Suggested test login (from the brief)
------------------------------------------------
Username: kyl_1
Password: Ch&&sec@ke99!
Cell:     +27838968976
First / last name: any names (used in the welcome message)

After login, choose:
1) Send Messages
2) Show recently sent messages  (Coming Soon.)
3) Quit

Sample send data from the brief:
Message 1 recipient: +27718693002
Message 1 text:      Hi Mike, can you join us for dinner tonight?
                     Choose 1 = Send
Message 2 recipient: 08575975889
Message 2 text:      Hi Keegan, did you receive the payment?
                     Choose 2 = Disregard
