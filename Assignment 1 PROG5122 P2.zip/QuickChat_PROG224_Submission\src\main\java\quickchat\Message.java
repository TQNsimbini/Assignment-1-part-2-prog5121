package quickchat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Part 2 sending messages. Recipient checks reuse the Part 1 Login cell-number
 * regular expression.
 */
public class Message {

    public static final int SEND = 1;
    public static final int DISREGARD = 2;
    public static final int STORE = 3;

    private static final Random RANDOM = new Random();
    private static final List<Message> SENT_MESSAGES = new ArrayList<>();
    private static int nextMessageNumber = 0;
    private static Path storeFile = Paths.get("storedMessages.json");

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String lastActionResult;

    public Message() {
        this.messageID = generateMessageID();
        this.messageNumber = nextMessageNumber;
    }

    public Message(String recipient, String message) {
        this();
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    public Message(String messageID, int messageNumber, String recipient, String message) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    public static void resetSentMessages() {
        SENT_MESSAGES.clear();
        nextMessageNumber = 0;
    }

    static void setStoreFile(Path path) {
        storeFile = path;
    }

    public static String generateMessageID() {
        long value = 1_000_000_000L + (Math.abs(RANDOM.nextLong()) % 9_000_000_000L);
        return String.valueOf(value);
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /**
     * Reuses Part 1 {@link Login#isValidCellNumber(String)} so recipient numbers
     * follow the same international-code rules as registration.
     */
    public String checkRecipientCell() {
        if (Login.isValidCellNumber(recipient)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String checkMessageLength() {
        if (message == null) {
            return "Please enter a message of less than 250 characters.";
        }
        if (message.length() <= 250) {
            return "Message ready to send.";
        }
        int excess = message.length() - 250;
        return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
    }

    public String createMessageHash() {
        String firstTwo = (messageID != null && messageID.length() >= 2)
                ? messageID.substring(0, 2)
                : "00";
        String firstWord = "";
        String lastWord = "";
        if (message != null && !message.isBlank()) {
            String[] words = message.trim().split("\\s+");
            firstWord = stripNonLetters(words[0]);
            lastWord = stripNonLetters(words[words.length - 1]);
        }
        messageHash = (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
        return messageHash;
    }

    private String stripNonLetters(String word) {
        return word.replaceAll("[^A-Za-z]", "");
    }

    /**
     * 1 = send, 2 = disregard, 3 = store.
     */
    public String SentMessage(int choice) {
        createMessageHash();
        switch (choice) {
            case SEND:
                SENT_MESSAGES.add(this);
                nextMessageNumber++;
                lastActionResult = "Message successfully sent.";
                break;
            case DISREGARD:
                lastActionResult = "Press 0 to delete the message.";
                break;
            case STORE:
                storeMessage();
                lastActionResult = "Message successfully stored.";
                break;
            default:
                lastActionResult = "Invalid option.";
                break;
        }
        return lastActionResult;
    }

    public String printMessages() {
        StringBuilder output = new StringBuilder();
        for (Message sent : SENT_MESSAGES) {
            output.append("Message ID: ").append(sent.messageID).append("\n");
            output.append("Message Hash: ").append(sent.messageHash).append("\n");
            output.append("Recipient: ").append(sent.recipient).append("\n");
            output.append("Message: ").append(sent.message).append("\n\n");
        }
        return output.toString().trim();
    }

    public int returnTotalMessagess() {
        return SENT_MESSAGES.size();
    }

    /**
     * Stores the message in JSON so it can be sent later.
     *
     * JSON writing uses the org.json library:
     * https://github.com/stleary/JSON-java
     */
    public void storeMessage() {
        try {
            JSONArray messages;
            if (Files.exists(storeFile) && Files.size(storeFile) > 0) {
                messages = new JSONArray(Files.readString(storeFile));
            } else {
                messages = new JSONArray();
            }
            JSONObject json = new JSONObject();
            json.put("messageID", messageID);
            json.put("messageHash", messageHash);
            json.put("recipient", recipient);
            json.put("message", message);
            json.put("numMessagesSent", messageNumber);
            messages.put(json);
            Files.writeString(storeFile, messages.toString(2));
        } catch (IOException e) {
            lastActionResult = "Could not store message: " + e.getMessage();
        }
    }

    public String getDisplayDetails() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public void setMessageNumber(int messageNumber) {
        this.messageNumber = messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageHash() {
        return messageHash;
    }
}
